//
//  CustomAlertView.m
//  AlertViewInitWith
//
//  Created by 李春菲 on 16/9/24.
//  Copyright © 2016年 lichunfei. All rights reserved.
//

#import "CustomAlertView.h"
/** 二进制转码RGB**/

#define UIColorFromRGBValue(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]


@implementation CustomAlertView
/** 单例**/

+(CustomAlertView *)CustomalerviewWithClass{
    
    static CustomAlertView * cutomalert = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cutomalert = [[CustomAlertView alloc]init];
    });
    
    
    return cutomalert ;
}


/** 提示view**/
-(UIView *)quickAlerViewWithArray:(NSArray *)array{
    CGFloat buttonH = 61;
    CGFloat buttonW= 250;
    
    //通过数组长度创建view的高度
    UIView * alert = [[UIView alloc] initWithFrame:CGRectMake(0, 0, buttonW, array.count * buttonH)];
    for (int i = 0; i < array.count; i++) {
        //因为有一条分割线 所以最下面是一层view
        UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, i*buttonH , buttonW, buttonH)];
        view.backgroundColor = [UIColor whiteColor];
        
        //创建button
        UIButton * button = [UIButton buttonWithType:(UIButtonTypeSystem)];
        button.frame = CGRectMake(0, 0, buttonW, buttonH);
        [button setTitle:array[i] forState:(UIControlStateNormal)];
        //所有button都关联一个点击方法,通过按钮上的title做区分
        [button addTarget:self action:@selector(alerviewbuttonAction:) forControlEvents:(UIControlEventTouchUpInside)];
        [view addSubview:button];
        
        //这里可以根据传值改变状态
        if ([array[i] isEqualToString:@"取消"]) {
            button.tintColor= [UIColor whiteColor];
            //绿色背景
            view.backgroundColor = UIColorFromRGBValue(0x82DFB0);
        }else{
            
            button.tintColor= UIColorFromRGBValue(0x333333);
            //分割线
            //如果不是最后一行
            UIView * lineview = [[UIView alloc] initWithFrame:CGRectMake(0, 60, buttonW, 1)];
             lineview.backgroundColor = UIColorFromRGBValue(0xefefef);
            [view addSubview:lineview];
        }
        [alert addSubview:view];
    }
    return alert;
}

-(void)alerviewbuttonAction:(UIButton *)bt{
    
    //代理方法
    [_delegate didSelectAlerViewButton:bt.titleLabel.text];
    
}

@end
