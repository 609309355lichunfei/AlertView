//
//  CustomAlertView.h
//  AlertViewInitWith
//
//  Created by 李春菲 on 16/9/24.
//  Copyright © 2016年 lichunfei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//代理方法
@protocol CustomAlerViewDelegate <NSObject>

//可选执行方法
@optional
//点击按钮下标时传递参数
-(void)didSelectAlerViewButton:(NSString *)title;
@end


@interface CustomAlertView : NSObject

//** 单例 **//
+(CustomAlertView *)CustomalerviewWithClass;

/** 快速创建提示框**/

-(UIView *)quickAlerViewWithArray:(NSArray *)array;

//代理属性
@property (assign,nonatomic)id<CustomAlerViewDelegate>delegate;

@end
