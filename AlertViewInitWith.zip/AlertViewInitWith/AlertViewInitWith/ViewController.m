//
//  ViewController.m
//  AlertViewInitWith
//
//  Created by 李春菲 on 16/9/24.
//  Copyright © 2016年 lichunfei. All rights reserved.
//

#import "ViewController.h"
#import "CustomAlertView.h"
@interface ViewController ()<CustomAlerViewDelegate>
@property (strong,nonatomic) UIView * alerview;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view addSubview:self.alerview];
    
}


- (IBAction)Prompt:(id)sender {
    
    [UIView animateWithDuration:0.1 animations:^{
        self.alerview.alpha = 1;
        self.alerview.hidden = NO;
    }];
}

-(UIView *)alerview{
    if (!_alerview) {
        //赋值
        _alerview = [[CustomAlertView CustomalerviewWithClass]quickAlerViewWithArray:@[@"店铺",@"关注",@"aaa",@"fds",@"取消",]];
        //设定中心,如果需要适配请layoutifNeed
        _alerview.center = self.view.center;
        //切圆
        _alerview.layer.masksToBounds = YES;
        _alerview.layer.cornerRadius= 10;
        //初始化状态为隐藏,透明度为0
        _alerview.hidden = YES;
        _alerview.alpha= 0.0;
        [CustomAlertView CustomalerviewWithClass].delegate = self;
        
    
    }
    return  _alerview;
}

//代理方法传值
-(void)didSelectAlerViewButton:(NSString *)title{
  [UIView animateWithDuration:0.1 animations:^{
      self.alerview.alpha= 0;
  }completion:^(BOOL finished) {
     //如果直接在动画隐藏不会出现动画效果,所以要在动画结束以后隐藏
      self.alerview.hidden = YES;
  }];
    NSLog(@"%@====",title);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
