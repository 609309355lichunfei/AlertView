//
//  ViewController.h
//  AlertViewInitWith
//
//  Created by 李春菲 on 16/9/24.
//  Copyright © 2016年 lichunfei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

